/* CampusVoice — Storage & Data Layer */

const CV = {
  get(key) { try { return JSON.parse(localStorage.getItem('cv_' + key)); } catch { return null; } },
  set(key, val) { localStorage.setItem('cv_' + key, JSON.stringify(val)); },
  del(key) { localStorage.removeItem('cv_' + key); }
};

export function seedAccounts() {
  if (CV.get('accounts_seeded')) return;
  CV.set('accounts', [
    { role: 'student',  username: 'student1', password: '1234',     name: 'Arjun Reddy',               branch: 'CSM', section: 'A', course: 'B.Tech', rollNo: '22CSM001' },
    { role: 'student',  username: 'student2', password: '1234',     name: 'Priya Sharma',              branch: 'ECE', section: 'B', course: 'B.Tech', rollNo: '22ECE042' },
    { role: 'student',  username: 'student3', password: '1234',     name: 'Rahul Mehta',               branch: 'CSM', section: 'B', course: 'B.Tech', rollNo: '22CSM064' },
    { role: 'incharge', username: 'ic_csma',  password: '1234',     name: 'Dr. Ravi Kumar',            branch: 'CSM', section: 'A' },
    { role: 'incharge', username: 'ic_eceb',  password: '1234',     name: 'Ms. Sunitha Rao',           branch: 'ECE', section: 'B' },
    { role: 'incharge', username: 'ic_csmb',  password: '1234',     name: 'Prof. Mahesh Verma',        branch: 'CSM', section: 'B' },
    { role: 'incharge', username: 'ic_csea',  password: '1234',     name: 'Dr. Lakshmi Naidu',         branch: 'CSE', section: 'A' },
    { role: 'hod',      username: 'hod_csm',  password: 'hod123',   name: 'Prof. Dr. V. Krishnaswamy', branch: 'CSM' },
    { role: 'hod',      username: 'hod_ece',  password: 'hod123',   name: 'Dr. Meena Iyer',            branch: 'ECE' },
    { role: 'hod',      username: 'hod_cse',  password: 'hod123',   name: 'Prof. Mahendra Reddy',      branch: 'CSE' },
    { role: 'hod',      username: 'hod_eee',  password: 'hod123',   name: 'Dr. Lakshmi Devi',          branch: 'EEE' },
    { role: 'admin',    username: 'admin',     password: 'admin123', name: 'Admin — Office of Dean' },
  ]);
  CV.set('complaints', []);
  CV.set('accounts_seeded', true);
}

export const Session = {
  get() { return CV.get('session'); },
  set(user) { CV.set('session', user); },
  clear() { CV.del('session'); },
};

export const Complaints = {
  getAll()   { return CV.get('complaints') || []; },
  save(list) { CV.set('complaints', list); },
  add(c)     { const l = this.getAll(); l.push(c); this.save(l); },
  getById(id){ return this.getAll().find(c => c.id === id) || null; },
  updateStatus(id, status, inchargeUser, note) {
    const list = this.getAll();
    const idx  = list.findIndex(c => c.id === id);
    if (idx === -1) return false;
    list[idx].status = status;
    if (inchargeUser) { list[idx].inchargeUsername = inchargeUser.username; list[idx].inchargeName = inchargeUser.name; }
    list[idx].history.push({ status, note: note || status, time: new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }) });
    this.save(list); return true;
  },
  forStudent(username) { return this.getAll().filter(c => c.studentUsername === username); },
  forClass(branch, section) { const cls = branch + '-' + section; return this.getAll().filter(c => c.class === cls); },
  forBranch(branch)  { return this.getAll().filter(c => c.class && c.class.split('-')[0] === branch); },
  delete(id) { this.save(this.getAll().filter(c => c.id !== id)); }
};

export const Accounts = {
  getAll()   { return CV.get('accounts') || []; },
  save(list) { CV.set('accounts', list); },
  find(username, password, role) { return this.getAll().find(a => a.username === username && a.password === password && a.role === role) || null; },
  findByUsername(u) { return this.getAll().find(a => a.username === u) || null; },
  usernameExists(u) { return this.getAll().some(a => a.username === u); },
  add(account)  { const l = this.getAll(); l.push(account); this.save(l); },
  getIncharges(){ return this.getAll().filter(a => a.role === 'incharge'); },
  getStudents() { return this.getAll().filter(a => a.role === 'student');  },
  getHODs()     { return this.getAll().filter(a => a.role === 'hod');      },
  update(username, fields) {
    const list = this.getAll();
    const idx  = list.findIndex(a => a.username === username);
    if (idx === -1) return false;
    Object.assign(list[idx], fields);
    this.save(list);
    const s = CV.get('session');
    if (s && s.username === username) CV.set('session', list[idx]);
    return true;
  }
};

export function statusLabel(s) {
  return { pending:'⏳ Pending', accepted:'📌 Accepted', working:'🔧 Working', solved:'✅ Solved', rejected:'❌ Rejected' }[s] || s;
}
export function statusClass(s) { return 'badge-' + (s || 'pending'); }

export function genId(prefix = 'CMP') { return prefix + Date.now() + Math.random().toString(36).slice(2,6).toUpperCase(); }

export const CAMPUS_EVENTS = [
  { text: 'Annual Technical Fest "Innovate 2025" — Registrations Open', date: 'Apr 10' },
  { text: 'End Semester Examinations commence', date: 'May 5' },
  { text: 'Sports Day — All students encouraged to participate', date: 'Apr 18' },
  { text: 'Industry Expert Talk: AI in Engineering', date: 'Apr 12' },
];
export const FACULTY_EVENTS = [
  { text: 'Faculty Coordination Meeting — Academic Block 2', date: 'Apr 8' },
  { text: 'Grade Submission Deadline', date: 'Apr 25' },
  { text: 'NAAC Preparation Workshop', date: 'Apr 14' },
];

export const ALL_BRANCHES = ['CSM','CSE','ECE','EEE','MECH','CIVIL','IT','AIDS'];
export const DEPT_COLORS = { CSM:'#6366f1', CSE:'#3b82f6', ECE:'#10b981', EEE:'#f59e0b', MECH:'#ef4444', CIVIL:'#8b5cf6', IT:'#06b6d4', AIDS:'#ec4899' };
export function deptColor(branch) { return DEPT_COLORS[branch] || '#6b7280'; }
