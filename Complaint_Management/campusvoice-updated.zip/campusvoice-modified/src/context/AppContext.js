import React, { createContext, useContext, useState, useCallback } from 'react';
import { Session } from '../utils/storage';

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(() => Session.get());
  const [theme, setTheme] = useState(() => localStorage.getItem('cv_theme') || 'light');
  const [toast, setToast] = useState(null);
  const [toastTimer, setToastTimer] = useState(null);

  const login = useCallback((user) => {
    Session.set(user);
    setCurrentUser(user);
  }, []);

  const logout = useCallback(() => {
    Session.clear();
    setCurrentUser(null);
  }, []);

  const refreshUser = useCallback(() => {
    setCurrentUser(Session.get());
  }, []);

  const toggleTheme = useCallback(() => {
    setTheme(t => {
      const next = t === 'dark' ? 'light' : 'dark';
      localStorage.setItem('cv_theme', next);
      document.documentElement.setAttribute('data-theme', next);
      return next;
    });
  }, []);

  const showToast = useCallback((msg, type = '') => {
    if (toastTimer) clearTimeout(toastTimer);
    setToast({ msg, type });
    const t = setTimeout(() => setToast(null), 3200);
    setToastTimer(t);
  }, [toastTimer]);

  // Apply theme to document
  React.useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  return (
    <AppContext.Provider value={{ currentUser, login, logout, refreshUser, theme, toggleTheme, toast, showToast }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() { return useContext(AppContext); }
