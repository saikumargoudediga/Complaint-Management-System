import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { seedAccounts } from './utils/storage';
import LoginPage from './pages/LoginPage';
import StudentPage from './pages/StudentPage';
import InchargePage from './pages/InchargePage';
import HODPage from './pages/HODPage';
import AdminPage from './pages/AdminPage';

seedAccounts();

function AppRouter() {
  const { currentUser, login } = useApp();

  if (!currentUser) {
    return <LoginPage onLogin={login} />;
  }

  switch (currentUser.role) {
    case 'student':  return <StudentPage />;
    case 'incharge': return <InchargePage />;
    case 'hod':      return <HODPage />;
    case 'admin':    return <AdminPage />;
    default:         return <LoginPage onLogin={login} />;
  }
}

export default function App() {
  return (
    <AppProvider>
      <AppRouter />
    </AppProvider>
  );
}
