import React from 'react';
import { useApp } from '../context/AppContext';
import { statusLabel, statusClass } from '../utils/storage';

/* ---- HEADER ---- */
export function Header({ homeLabel, onLogoClick }) {
  const { currentUser, logout, theme, toggleTheme, showToast } = useApp();
  const handleLogout = () => {
    logout();
    showToast('Logged out. See you soon!');
  };
  return (
    <header className="cv-header">
      <button className="cv-logo btn-reset" onClick={onLogoClick || (() => {})}>
        <div className="cv-logo-icon">📢</div>
        <span>CampusVoice</span>
      </button>
      <div className="cv-header-right">
        {currentUser && (
          <div className="user-badge">
            <div className="status-dot"></div>
            <span>{currentUser.name}</span>
          </div>
        )}
        <div className="theme-toggle" onClick={toggleTheme}>
          <span className="theme-label">☀️</span>
          <div className="toggle-track">
            <div className="toggle-thumb">{theme === 'dark' ? '🌙' : '☀️'}</div>
          </div>
          <span className="theme-label">🌙</span>
        </div>
        {currentUser && (
          <button className="btn-logout" onClick={handleLogout}>← Logout</button>
        )}
      </div>
    </header>
  );
}

export function LoginHeader() {
  const { theme, toggleTheme } = useApp();
  return (
    <header className="cv-header">
      <div className="cv-logo">
        <div className="cv-logo-icon">📢</div>
        <span>CampusVoice</span>
      </div>
      <div className="cv-header-right">
        <div className="theme-toggle" onClick={toggleTheme}>
          <span className="theme-label">☀️</span>
          <div className="toggle-track">
            <div className="toggle-thumb">{theme === 'dark' ? '🌙' : '☀️'}</div>
          </div>
          <span className="theme-label">🌙</span>
        </div>
      </div>
    </header>
  );
}

export function Footer() {
  return (
    <footer className="cv-footer">
      <div>© 2025 <strong>CampusVoice</strong> — Complaint Management System for Colleges</div>
      <div className="footer-right">
        <span className="footer-badge">🔒 E2E Encrypted</span>
        <span>Built with ❤️ for students</span>
      </div>
    </footer>
  );
}

/* ---- TOAST ---- */
export function Toast() {
  const { toast } = useApp();
  if (!toast) return null;
  return (
    <div id="cv-toast" className={`show${toast.type ? ' ' + toast.type : ''}`}>
      {toast.msg}
    </div>
  );
}

/* ---- MODAL ---- */
export function Modal({ open, onClose, title, subtitle, children, footer }) {
  if (!open) return null;
  return (
    <div className="modal-overlay open" onClick={e => { if (e.target.classList.contains('modal-overlay')) onClose(); }}>
      <div className="modal">
        <div className="modal-title">{title}</div>
        {subtitle && <p className="modal-sub">{subtitle}</p>}
        <div>{children}</div>
        {footer && <div className="modal-footer">{footer}</div>}
      </div>
    </div>
  );
}

/* ---- EVENTS BANNER ---- */
export function EventsBanner({ events }) {
  return (
    <div className="events-banner">
      <div className="events-banner-title">📅 Notices & Events</div>
      {events.map((e, i) => (
        <div className="event-row" key={i}>
          <div className="event-dot"></div>
          <span>{e.text}</span>
          <span className="event-date">{e.date}</span>
        </div>
      ))}
    </div>
  );
}

/* ---- STATUS BADGE ---- */
export function StatusBadge({ status }) {
  return <span className={`badge ${statusClass(status)}`}>{statusLabel(status)}</span>;
}

/* ---- COMPLAINT CARD (student view) ---- */
export function ComplaintCard({ complaint }) {
  const STEPS = ['pending', 'accepted', 'working', 'solved'];
  const stepIdx = STEPS.indexOf(complaint.status);
  const icons = ['📤', '📌', '🔧', '✅'];
  const labels = ['Submitted', 'Accepted', 'Working', 'Solved'];

  return (
    <div className="complaint-card">
      <div className="encrypted-tag">🔒 Encrypted — visible only to you and your incharge</div>
      <div className="complaint-top">
        <div>
          <div className="complaint-title">{complaint.title}</div>
          <div className="complaint-chips">
            <span className="meta-chip">📋 {complaint.rollNo}</span>
            <span className="meta-chip">🏫 {complaint.class}</span>
            <span className="meta-chip">📅 {complaint.createdAt}</span>
          </div>
        </div>
        <StatusBadge status={complaint.status} />
      </div>

      <div className="status-progress">
        {STEPS.map((s, i) => {
          const cls = i < stepIdx ? 'done' : (i === stepIdx ? 'active' : '');
          const lineClass = i < stepIdx ? 'done' : '';
          return (
            <React.Fragment key={s}>
              {i > 0 && <div className={`progress-line ${lineClass}`}></div>}
              <div className={`progress-step ${cls}`}>
                <div className="progress-step-circle">{icons[i]}</div>
                <div className="progress-step-label">{labels[i]}</div>
              </div>
            </React.Fragment>
          );
        })}
      </div>

      <p className="complaint-desc">{complaint.description}</p>
      {complaint.inchargeName && (
        <p style={{ fontSize: '0.82rem', color: 'var(--text2)', marginBottom: '0.5rem' }}>
          👤 Handled by: <strong>{complaint.inchargeName}</strong>
        </p>
      )}
      {complaint.photo && <img src={complaint.photo} className="photo-thumb" style={{ display: 'block', marginBottom: '0.8rem' }} alt="evidence" />}
      <div className="activity-log">
        <div className="activity-log-title">Activity Log</div>
        {complaint.history.map((h, i) => (
          <div className="activity-entry" key={i}>{h.time} — {h.note}</div>
        ))}
      </div>
    </div>
  );
}

/* ---- FILTER BAR ---- */
export function FilterBar({ filters, active, onChange }) {
  return (
    <div className="filter-bar fade-up fade-up-2">
      {filters.map(f => (
        <button
          key={f.value}
          className={`filter-btn${active === f.value ? ' active' : ''}${f.className ? ' ' + f.className : ''}`}
          onClick={() => onChange(f.value)}
        >
          {f.label}
        </button>
      ))}
    </div>
  );
}

/* ---- BACK BUTTON ---- */
export function BackBtn({ onClick, label = '← Back to Dashboard' }) {
  return <button className="back-btn fade-up" onClick={onClick}>{label}</button>;
}

/* ---- EMPTY STATE ---- */
export function EmptyState({ icon, message }) {
  return (
    <div className="empty-state">
      <div className="empty-state-icon">{icon}</div>
      <p dangerouslySetInnerHTML={{ __html: message }} />
    </div>
  );
}

/* ---- PHOTO LIGHTBOX ---- */
export function Lightbox({ src, onClose }) {
  React.useEffect(() => {
    const handler = e => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [onClose]);

  if (!src) return null;
  return (
    <div className="photo-lightbox open" onClick={onClose}>
      <div className="lightbox-close" onClick={onClose}>✕</div>
      <img src={src} alt="complaint" onClick={e => e.stopPropagation()} />
    </div>
  );
}
