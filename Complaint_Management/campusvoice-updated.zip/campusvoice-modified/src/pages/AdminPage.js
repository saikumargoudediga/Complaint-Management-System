import React, { useState, useCallback } from 'react';
import { useApp } from '../context/AppContext';
import { Complaints, Accounts, ALL_BRANCHES, deptColor } from '../utils/storage';
import { Header, Footer, Toast, StatusBadge, BackBtn, EmptyState, FilterBar, Modal, Lightbox } from '../components/Shared';

const STATUS_FILTERS = [
  { value: 'all', label: 'All Statuses' },
  { value: 'pending', label: '⏳ Pending' },
  { value: 'accepted', label: '📌 Accepted' },
  { value: 'working', label: '🔧 Working' },
  { value: 'solved', label: '✅ Solved' },
  { value: 'rejected', label: '❌ Rejected' },
  { value: 'unaccepted', label: '🚨 Not Accepted', className: 'hod-filter-urgent' },
];

/* ---- DASHBOARD ---- */
function Dashboard({ user, onNavigate }) {
  const all = Complaints.getAll();
  const total   = all.length;
  const pending = all.filter(c => c.status === 'pending').length;
  const inprog  = all.filter(c => c.status === 'accepted' || c.status === 'working').length;
  const solved  = all.filter(c => c.status === 'solved').length;
  const incharges = Accounts.getIncharges();
  const hods      = Accounts.getHODs();

  return (
    <main className="page-wrap">
      <div className="page-header fade-up">
        <div className="hod-role-tag admin-tag">System Admin</div>
        <h1>Admin Control Panel 🔐</h1>
        <p>Logged in as: {user.name}</p>
      </div>

      <div className="section-title fade-up fade-up-1">System-Wide Statistics</div>
      <div className="grid grid-4 fade-up fade-up-1" style={{ marginBottom:'2rem' }}>
        <div className="card stat-card"><div className="stat-icon" style={{ background:'var(--accent-soft)' }}>📋</div><div><h3>{total}</h3><p>Total Complaints</p></div></div>
        <div className="card stat-card"><div className="stat-icon" style={{ background:'var(--red-soft)' }}>⏳</div><div><h3>{pending}</h3><p>Pending</p></div></div>
        <div className="card stat-card"><div className="stat-icon" style={{ background:'var(--blue-soft)' }}>🔧</div><div><h3>{inprog}</h3><p>In Progress</p></div></div>
        <div className="card stat-card"><div className="stat-icon" style={{ background:'var(--green-soft)' }}>✅</div><div><h3>{solved}</h3><p>Resolved</p></div></div>
      </div>

      <div className="section-title fade-up fade-up-2">Department Overview</div>
      <div className="dept-cards-grid fade-up fade-up-2">
        {ALL_BRANCHES.map(branch => {
          const bc  = Complaints.forBranch(branch);
          const tot = bc.length;
          const pen = bc.filter(c=>c.status==='pending').length;
          const act = bc.filter(c=>c.status==='accepted'||c.status==='working').length;
          const sol = bc.filter(c=>c.status==='solved').length;
          const ics = incharges.filter(ic=>ic.branch===branch).length;
          const hod = hods.find(h=>h.branch===branch);
          const col = deptColor(branch);
          return (
            <div className="dept-card" key={branch}>
              <div className="dept-card-bar" style={{ background:col }}></div>
              <div className="dept-card-top">
                <div className="dept-card-name">{branch}</div>
                {pen>0 ? <span className="badge badge-pending">{pen} pending</span> : <span className="badge badge-solved">All clear</span>}
              </div>
              <div className="dept-card-hod">🏛️ HOD: {hod ? hod.name : <em style={{ color:'var(--text3)' }}>Not assigned</em>}</div>
              <div className="dept-card-stats">
                <div className="dcs-box"><span className="dcs-val">{tot}</span><span className="dcs-lbl">Total</span></div>
                <div className="dcs-box"><span className="dcs-val" style={{ color:'#ef4444' }}>{pen}</span><span className="dcs-lbl">Pending</span></div>
                <div className="dcs-box"><span className="dcs-val" style={{ color:'#3b82f6' }}>{act}</span><span className="dcs-lbl">Active</span></div>
                <div className="dcs-box"><span className="dcs-val" style={{ color:'#10b981' }}>{sol}</span><span className="dcs-lbl">Solved</span></div>
              </div>
              <div className="dept-card-footer">👨‍🏫 {ics} incharge{ics!==1?'s':''}</div>
            </div>
          );
        })}
      </div>

      <div className="section-title fade-up fade-up-3" style={{ marginTop:'2.5rem' }}>Navigation</div>
      <div className="grid grid-4 fade-up fade-up-3" style={{ marginBottom:'2rem' }}>
        {[
          { view:'complaints', icon:'📋', bg:'var(--accent-soft)', title:'All Complaints',       desc:'Every complaint system-wide, filterable by dept & status' },
          { view:'incharges',  icon:'👥', bg:'var(--blue-soft)',   title:'Incharge Overview',    desc:'See how many complaints each incharge holds per department' },
          { view:'pending',    icon:'⏳', bg:'var(--red-soft)',    title:'Pending by Department',desc:'Which departments still have unresolved pending complaints' },
          { view:'accounts',   icon:'➕', bg:'var(--green-soft)',  title:'Manage All Accounts',  desc:'Create or edit any account across all departments' },
        ].map(item => (
          <div key={item.view} className="card action-card card-clickable" onClick={() => onNavigate(item.view)}>
            <div className="action-card-icon" style={{ background:item.bg }}>{item.icon}</div>
            <h3>{item.title}</h3>
            <p>{item.desc}</p>
          </div>
        ))}
      </div>
    </main>
  );
}

/* ---- ALL COMPLAINTS ---- */
function AllComplaints({ onBack }) {
  const [deptFilter, setDeptFilter]     = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [lightboxSrc, setLightboxSrc]   = useState(null);

  const branches = [...new Set(Complaints.getAll().map(c => c.class?.split('-')[0]).filter(Boolean))].sort();
  const deptFilters = [{ value:'all', label:'All Depts' }, ...branches.map(b => ({ value:b, label:b }))];

  const order = { pending:0, accepted:1, working:2, solved:3, rejected:4 };
  let all = Complaints.getAll().slice().sort((a,b) => (order[a.status]||0)-(order[b.status]||0));
  if (deptFilter !== 'all') all = all.filter(c => c.class?.split('-')[0] === deptFilter);
  if (statusFilter === 'unaccepted') all = all.filter(c => c.status === 'pending' && !c.inchargeUsername);
  else if (statusFilter !== 'all')   all = all.filter(c => c.status === statusFilter);

  return (
    <main className="page-wrap">
      <BackBtn onClick={onBack} />
      <div className="page-header fade-up fade-up-1"><h1>All Complaints 📋</h1><p>System-wide view — every complaint from every department.</p></div>
      <div className="filter-bar fade-up fade-up-2">
        {deptFilters.map(f => (
          <button key={f.value} className={`filter-btn${deptFilter===f.value?' active':''}`}
            style={f.value!=='all'?{ borderColor:deptColor(f.value), color: deptFilter===f.value?'white':deptColor(f.value) }:{}}
            onClick={() => setDeptFilter(f.value)}>{f.label}</button>
        ))}
      </div>
      <FilterBar filters={STATUS_FILTERS} active={statusFilter} onChange={setStatusFilter} />
      <div className="fade-up fade-up-3">
        {!all.length
          ? <EmptyState icon="🔍" message="No complaints match this filter." />
          : all.map(c => {
            const branch   = c.class?.split('-')[0] || '?';
            const col      = deptColor(branch);
            const isUrgent = c.status==='pending' && !c.inchargeUsername;
            return (
              <div className={`hod-complaint-card${isUrgent?' urgent':''}`} key={c.id}>
                <div className="hod-complaint-header">
                  <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                    <span style={{ background:col, width:10, height:10, borderRadius:'50%', display:'inline-block', flexShrink:0 }}></span>
                    <div className="hod-complaint-title">{c.title}</div>
                  </div>
                  <StatusBadge status={c.status} />
                </div>
                <div className="hod-meta-row">
                  <span className="meta-chip">🎓 {c.studentName}</span>
                  <span className="meta-chip">📋 {c.rollNo}</span>
                  <span className="meta-chip">🏫 {c.class}</span>
                  <span className="meta-chip">📚 {c.course}</span>
                  <span className="meta-chip">📅 {c.createdAt}</span>
                </div>
                <div className="incharge-info">
                  <span>👨‍🏫 Incharge:</span>
                  {c.inchargeName ? <strong>{c.inchargeName}</strong> : <span className="no-incharge">⚠️ Not yet accepted</span>}
                </div>
                {c.rejectReason && <div className="reject-reason-hod">⚠️ Rejection reason: {c.rejectReason}</div>}
                <p className="hod-complaint-desc">{c.description}</p>
                {c.photo && <img src={c.photo} className="photo-thumb photo-thumb-clickable" style={{ display:'block', marginBottom:'0.7rem' }} onClick={() => setLightboxSrc(c.photo)} alt="evidence" />}
                <div className="activity-log">
                  <div className="activity-log-title">Activity Log</div>
                  {c.history.map((h,i) => <div className="activity-entry" key={i}>{h.time} — {h.note}</div>)}
                </div>
              </div>
            );
          })
        }
      </div>
      <Lightbox src={lightboxSrc} onClose={() => setLightboxSrc(null)} />
    </main>
  );
}

/* ---- INCHARGE OVERVIEW ---- */
function InchargeOverview({ onBack }) {
  const incharges = Accounts.getIncharges();
  const byBranch = {};
  incharges.forEach(ic => { if (!byBranch[ic.branch]) byBranch[ic.branch]=[]; byBranch[ic.branch].push(ic); });

  return (
    <main className="page-wrap">
      <BackBtn onClick={onBack} />
      <div className="page-header fade-up fade-up-1"><h1>Incharge Overview 👥</h1><p>See every class incharge across all departments.</p></div>
      {!incharges.length
        ? <EmptyState icon="👥" message="No incharges in the system." />
        : Object.entries(byBranch).sort().map(([branch, ics]) => {
          const col = deptColor(branch);
          return (
            <div key={branch} style={{ marginBottom:'2rem' }}>
              <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:'0.75rem' }}>
                <span style={{ width:14, height:14, borderRadius:'50%', background:col, display:'inline-block' }}></span>
                <h3 style={{ fontFamily:'Syne,sans-serif', fontWeight:700 }}>{branch} Department</h3>
              </div>
              {ics.map(ic => {
                const cls     = ic.branch + '-' + ic.section;
                const icAll   = Complaints.forClass(ic.branch, ic.section);
                const pending = icAll.filter(c=>c.status==='pending').length;
                const active  = icAll.filter(c=>c.status==='accepted'||c.status==='working').length;
                const solved  = icAll.filter(c=>c.status==='solved').length;
                return (
                  <div className="faculty-mgmt-card" key={ic.username} style={{ marginBottom:'0.75rem' }}>
                    <div className="faculty-mgmt-header">
                      <div>
                        <div className="faculty-mgmt-name">👨‍🏫 {ic.name}</div>
                        <div style={{ fontSize:'0.82rem', color:'var(--text2)', marginTop:2 }}>Class: <strong>{cls}</strong></div>
                      </div>
                      <span className={`badge ${pending>0?'badge-pending':'badge-solved'}`}>{pending>0?`${pending} pending`:'All clear'}</span>
                    </div>
                    <div className="faculty-mgmt-stats">
                      <div className="fstat">📋 Total: <strong>{icAll.length}</strong></div>
                      <div className="fstat">⏳ Pending: <strong>{pending}</strong></div>
                      <div className="fstat">🔧 Active: <strong>{active}</strong></div>
                      <div className="fstat">✅ Solved: <strong>{solved}</strong></div>
                    </div>
                  </div>
                );
              })}
            </div>
          );
        })
      }
    </main>
  );
}

/* ---- PENDING BY DEPT ---- */
function PendingByDept({ onBack }) {
  const deptStats = ALL_BRANCHES.map(branch => {
    const bc      = Complaints.forBranch(branch);
    const pending = bc.filter(c=>c.status==='pending');
    const noIncharge = pending.filter(c=>!c.inchargeUsername);
    return { branch, pending:pending.length, noIncharge:noIncharge.length, total:bc.length };
  }).filter(d => d.pending > 0).sort((a,b) => b.noIncharge - a.noIncharge || b.pending - a.pending);

  return (
    <main className="page-wrap">
      <BackBtn onClick={onBack} />
      <div className="page-header fade-up fade-up-1"><h1>Pending by Department ⏳</h1><p>Departments with unresolved pending complaints — sorted by urgency.</p></div>
      {!deptStats.length
        ? <EmptyState icon="🎉" message="No pending complaints anywhere! All clear across all departments." />
        : deptStats.map(d => {
          const col = deptColor(d.branch);
          return (
            <div className="dept-pending-card" key={d.branch} style={{ borderLeft:`4px solid ${col}` }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'0.6rem' }}>
                <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                  <span style={{ width:12, height:12, borderRadius:'50%', background:col, display:'inline-block' }}></span>
                  <strong style={{ fontFamily:'Syne,sans-serif', fontSize:'1.05rem' }}>{d.branch}</strong>
                </div>
                <span className="badge badge-pending">{d.pending} pending</span>
              </div>
              <div style={{ display:'flex', gap:'1.5rem', fontSize:'0.85rem', color:'var(--text2)' }}>
                <span>📋 Total complaints: <strong>{d.total}</strong></span>
                <span>⏳ Pending: <strong style={{ color:'var(--red)' }}>{d.pending}</strong></span>
                {d.noIncharge > 0 && <span>🚨 Not yet accepted: <strong style={{ color:'var(--red)' }}>{d.noIncharge}</strong></span>}
              </div>
            </div>
          );
        })
      }
    </main>
  );
}

/* ---- MANAGE ALL ACCOUNTS ---- */
function AccountsView({ onBack, showToast }) {
  const [newRole, setNewRole] = useState('incharge');
  const [form, setForm] = useState({ name:'', username:'', password:'', branch:'', section:'', course:'', rollNo:'' });
  const [search, setSearch] = useState('');
  const [editUsername, setEditUsername] = useState(null);
  const [editForm, setEditForm] = useState({});
  const [, forceUpdate] = useState(0);
  const refresh = () => forceUpdate(n => n + 1);
  const setF = (k,v) => setForm(f => ({...f,[k]:v}));

  const createAccount = () => {
    if (!form.name || !form.username || !form.password) { showToast('Name, username, and password are required', 'error'); return; }
    if (form.password.length < 4) { showToast('Password must be at least 4 characters', 'error'); return; }
    if (Accounts.usernameExists(form.username)) { showToast('Username already exists', 'error'); return; }
    if (newRole !== 'admin' && !form.branch) { showToast('Branch is required', 'error'); return; }

    let acc = { role:newRole, name:form.name, username:form.username, password:form.password };
    if (newRole === 'incharge') {
      if (!form.section) { showToast('Select a section', 'error'); return; }
      acc.branch = form.branch; acc.section = form.section;
    } else if (newRole === 'student') {
      if (!form.section||!form.course||!form.rollNo) { showToast('All student fields are required','error'); return; }
      acc.branch=form.branch; acc.section=form.section; acc.course=form.course; acc.rollNo=form.rollNo;
    } else if (newRole === 'hod') {
      acc.branch = form.branch;
    }
    Accounts.add(acc);
    setForm({ name:'', username:'', password:'', branch:'', section:'', course:'', rollNo:'' });
    showToast(`✅ Account created for ${form.name}`, 'success');
    refresh();
  };

  const openEdit = (username) => {
    const u = Accounts.findByUsername(username);
    setEditUsername(username);
    setEditForm({ name:u.name||'', branch:u.branch||'', section:u.section||'', course:u.course||'', rollNo:u.rollNo||'', password:'' });
  };

  const confirmEdit = () => {
    const u = Accounts.findByUsername(editUsername);
    if (!editForm.name) { showToast('Name is required','error'); return; }
    if (editForm.password && editForm.password.length < 4) { showToast('Password must be at least 4 characters','error'); return; }
    const updates = { name:editForm.name };
    if (editForm.password) updates.password = editForm.password;
    if (u.role==='hod') updates.branch = editForm.branch;
    if (u.role==='incharge'||u.role==='student') { updates.branch=editForm.branch; updates.section=editForm.section; }
    if (u.role==='student') { updates.course=editForm.course; updates.rollNo=editForm.rollNo; }
    Accounts.update(editUsername, updates);
    setEditUsername(null);
    showToast('✅ Account updated successfully','success');
    refresh();
  };

  const roleIcon  = { student:'🎓', incharge:'👨‍🏫', hod:'🏛️', admin:'🔐' };
  const roleCls   = { student:'role-student', incharge:'role-incharge', hod:'role-hod', admin:'role-admin' };
  const roleLabel = { student:'Student', incharge:'Incharge', hod:'HOD', admin:'Admin' };

  const q = search.toLowerCase();
  const allAccounts = Accounts.getAll().filter(a =>
    !q || a.name.toLowerCase().includes(q) || a.username.toLowerCase().includes(q) || (a.branch||'').toLowerCase().includes(q)
  );

  return (
    <main className="page-wrap">
      <BackBtn onClick={onBack} />
      <div className="page-header fade-up fade-up-1"><h1>Manage All Accounts ➕</h1><p>Create or edit student, incharge, and HOD accounts across all departments.</p></div>
      <div className="grid grid-2 fade-up fade-up-2" style={{ alignItems:'flex-start' }}>
        <div className="card">
          <div className="section-title">New Account</div>
          <div className="form-group"><label>Account Type *</label>
            <select value={newRole} onChange={e => setNewRole(e.target.value)}>
              <option value="incharge">Incharge / Faculty</option>
              <option value="student">Student</option>
              <option value="hod">Head of Department (HOD)</option>
            </select>
          </div>
          <div className="form-group"><label>Full Name *</label><input type="text" value={form.name} onChange={e => setF('name',e.target.value)} placeholder="Full name" /></div>
          <div className="form-group"><label>Username *</label><input type="text" value={form.username} onChange={e => setF('username',e.target.value)} placeholder="Unique login username" /></div>
          <div className="form-group"><label>Password *</label><input type="password" value={form.password} onChange={e => setF('password',e.target.value)} placeholder="Set a password" /></div>
          {newRole !== 'admin' && (
            <div className="form-row">
              <div className="form-group"><label>Branch *</label>
                <select value={form.branch} onChange={e => setF('branch',e.target.value)}>
                  <option value="">Select</option>{ALL_BRANCHES.map(b=><option key={b}>{b}</option>)}
                </select>
              </div>
              {newRole !== 'hod' && (
                <div className="form-group"><label>Section *</label>
                  <select value={form.section} onChange={e => setF('section',e.target.value)}>
                    <option value="">Select</option>{['A','B','C','D'].map(s=><option key={s}>{s}</option>)}
                  </select>
                </div>
              )}
            </div>
          )}
          {newRole === 'student' && <>
            <div className="form-group"><label>Course *</label>
              <select value={form.course} onChange={e => setF('course',e.target.value)}>
                <option value="">Select</option>{['B.Tech','M.Tech','MBA','MCA','BCA','B.Sc'].map(c=><option key={c}>{c}</option>)}
              </select>
            </div>
            <div className="form-group"><label>Roll Number *</label><input type="text" value={form.rollNo} onChange={e => setF('rollNo',e.target.value)} placeholder="e.g. 22CSM001" /></div>
          </>}
          <button className="btn btn-primary btn-full" style={{ marginTop:'0.5rem' }} onClick={createAccount}>➕ Create Account</button>
        </div>
        <div>
          <div className="section-title">All Accounts</div>
          <div style={{ marginBottom:'0.75rem' }}>
            <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="🔍 Search accounts..."
              style={{ width:'100%', padding:'8px 12px', border:'1px solid var(--border)', borderRadius:8, background:'var(--surface)', color:'var(--text)', fontSize:'0.85rem' }} />
          </div>
          <div id="accounts-list">
            {!allAccounts.length
              ? <div className="empty-state"><p>No accounts match your search.</p></div>
              : allAccounts.map(a => (
                <div className="account-item" key={a.username}>
                  <div className="account-item-icon" style={{ background:a.role==='incharge'?'var(--blue-soft)':a.role==='hod'?'var(--green-soft)':a.role==='admin'?'var(--yellow-soft)':'var(--accent-soft)' }}>
                    {roleIcon[a.role]||'👤'}
                  </div>
                  <div className="account-item-info">
                    <strong>{a.name}</strong>
                    <span>{a.branch ? `${a.branch}${a.section?'-'+a.section:''} · ` : ''}{a.username}</span>
                  </div>
                  <span className={`account-item-role ${roleCls[a.role]||''}`}>{roleLabel[a.role]||a.role}</span>
                  {a.role !== 'admin' && (
                    <button className="btn btn-ghost btn-xs" style={{ marginLeft:'0.4rem' }} onClick={() => openEdit(a.username)}>✏️</button>
                  )}
                </div>
              ))
            }
          </div>
        </div>
      </div>

      {/* Edit Account Modal */}
      {editUsername && (() => {
        const u = Accounts.findByUsername(editUsername);
        return (
          <Modal open onClose={() => setEditUsername(null)} title={`✏️ Edit — ${u.name}`} subtitle="Update bio details. Username cannot be changed."
            footer={<>
              <button className="btn btn-ghost" onClick={() => setEditUsername(null)}>Cancel</button>
              <button className="btn btn-primary btn-full" onClick={confirmEdit}>💾 Save Changes</button>
            </>}
          >
            <div className="form-group"><label>Full Name *</label><input type="text" value={editForm.name} onChange={e => setEditForm(f=>({...f,name:e.target.value}))} placeholder="Full name" /></div>
            {(u.role==='hod'||u.role==='incharge'||u.role==='student') && (
              <div className="form-group"><label>Branch *</label>
                <select value={editForm.branch} onChange={e => setEditForm(f=>({...f,branch:e.target.value}))}>
                  <option value="">Select</option>{ALL_BRANCHES.map(b=><option key={b}>{b}</option>)}
                </select>
              </div>
            )}
            {(u.role==='incharge'||u.role==='student') && (
              <div className="form-group"><label>Section *</label>
                <select value={editForm.section} onChange={e => setEditForm(f=>({...f,section:e.target.value}))}>
                  <option value="">Select</option>{['A','B','C','D'].map(s=><option key={s}>{s}</option>)}
                </select>
              </div>
            )}
            {u.role==='student' && <>
              <div className="form-group"><label>Course *</label>
                <select value={editForm.course} onChange={e => setEditForm(f=>({...f,course:e.target.value}))}>
                  <option value="">Select</option>{['B.Tech','M.Tech','MBA','MCA','BCA','B.Sc'].map(c=><option key={c}>{c}</option>)}
                </select>
              </div>
              <div className="form-group"><label>Roll Number *</label><input type="text" value={editForm.rollNo} onChange={e => setEditForm(f=>({...f,rollNo:e.target.value}))} /></div>
            </>}
            <div className="form-group"><label>New Password <span style={{ color:'var(--text3)', fontSize:'0.78rem' }}>(leave blank to keep current)</span></label>
              <input type="password" value={editForm.password} onChange={e => setEditForm(f=>({...f,password:e.target.value}))} placeholder="Set new password" />
            </div>
          </Modal>
        );
      })()}
    </main>
  );
}

/* ---- MAIN ---- */
export default function AdminPage() {
  const { currentUser, showToast } = useApp();
  const [view, setView] = useState('dashboard');
  const nav = useCallback(v => { setView(v); window.scrollTo({ top:0, behavior:'smooth' }); }, []);

  return (
    <>
      <Header onLogoClick={() => nav('dashboard')} />
      {view === 'dashboard'  && <Dashboard user={currentUser} onNavigate={nav} />}
      {view === 'complaints' && <AllComplaints onBack={() => nav('dashboard')} />}
      {view === 'incharges'  && <InchargeOverview onBack={() => nav('dashboard')} />}
      {view === 'pending'    && <PendingByDept onBack={() => nav('dashboard')} />}
      {view === 'accounts'   && <AccountsView onBack={() => nav('dashboard')} showToast={showToast} />}
      <Footer />
      <Toast />
    </>
  );
}
