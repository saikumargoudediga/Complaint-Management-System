import React, { useState, useCallback } from 'react';
import { useApp } from '../context/AppContext';
import { Complaints, Accounts, genId } from '../utils/storage';
import { Header, Footer, Toast, StatusBadge, BackBtn, EmptyState, FilterBar, Modal, Lightbox } from '../components/Shared';

const STATUS_FILTERS = [
  { value: 'all', label: 'All' },
  { value: 'pending', label: '⏳ Pending' },
  { value: 'accepted', label: '📌 Accepted' },
  { value: 'working', label: '🔧 Working' },
  { value: 'solved', label: '✅ Solved' },
  { value: 'rejected', label: '❌ Rejected' },
  { value: 'unaccepted', label: '🚨 Not Accepted', className: 'hod-filter-urgent' },
];

/* ---- DASHBOARD ---- */
function Dashboard({ user, onNavigate }) {
  const branch = user.branch;
  const all = Complaints.forBranch(branch);
  const incharges = Accounts.getIncharges().filter(ic => ic.branch === branch);
  const total   = all.length;
  const pending = all.filter(c => c.status === 'pending').length;
  const inprog  = all.filter(c => c.status === 'accepted' || c.status === 'working').length;
  const solved  = all.filter(c => c.status === 'solved').length;

  return (
    <main className="page-wrap">
      <div className="page-header fade-up">
        <div className="hod-role-tag">Head of Department</div>
        <h1>{branch} Department Overview 🏛️</h1>
        <p>{user.name} — HOD, {branch} Department</p>
      </div>

      <div className="section-title fade-up fade-up-1">Department Statistics</div>
      <div className="grid grid-4 fade-up fade-up-1" style={{ marginBottom: '2rem' }}>
        <div className="card stat-card"><div className="stat-icon" style={{ background:'var(--accent-soft)' }}>📋</div><div><h3>{total}</h3><p>Total Complaints</p></div></div>
        <div className="card stat-card"><div className="stat-icon" style={{ background:'var(--red-soft)' }}>⏳</div><div><h3>{pending}</h3><p>Pending</p></div></div>
        <div className="card stat-card"><div className="stat-icon" style={{ background:'var(--blue-soft)' }}>🔧</div><div><h3>{inprog}</h3><p>In Progress</p></div></div>
        <div className="card stat-card"><div className="stat-icon" style={{ background:'var(--green-soft)' }}>✅</div><div><h3>{solved}</h3><p>Resolved</p></div></div>
      </div>

      <div className="hod-main-grid fade-up fade-up-2">
        <div>
          <div className="section-title">Faculty Status</div>
          {!incharges.length
            ? <EmptyState icon="👥" message={`No incharges found for ${branch} department.`} />
            : incharges.map(ic => {
              const cls = ic.branch + '-' + ic.section;
              const icComplaints = Complaints.forClass(ic.branch, ic.section);
              const icPending = icComplaints.filter(c => c.status === 'pending').length;
              const icAccepted = icComplaints.filter(c => c.inchargeUsername === ic.username && c.status !== 'pending').length;
              return (
                <div className="faculty-card" key={ic.username}>
                  <div className="faculty-avatar">👨‍🏫</div>
                  <div className="faculty-card-info">
                    <strong>{ic.name} {ic.assignedFrom && <span className="assign-tag">📋 Covering {ic.assignedFrom}</span>}</strong>
                    <span>{cls} · {icComplaints.length} total · {icAccepted} accepted</span>
                  </div>
                  {icPending > 0
                    ? <span className="badge badge-pending">{icPending} pending</span>
                    : <span className="badge badge-solved">All clear</span>
                  }
                  <div className="faculty-card-actions">
                    {icPending > 0 && <button className="btn btn-yellow btn-xs" onClick={() => alert(`🔔 Reminder sent to ${ic.name}`)}>🔔</button>}
                    <button className="btn btn-blue btn-xs" onClick={() => onNavigate('faculty')} title="Assign job">📋</button>
                  </div>
                </div>
              );
            })
          }
        </div>
        <div>
          <div className="section-title">Navigation</div>
          <div style={{ display:'flex', flexDirection:'column', gap:'0.75rem' }}>
            {[
              { view:'complaints', icon:'📋', bg:'var(--accent-soft)', title:'Department Complaints', desc:'All complaints from your branch — filtered to your department only' },
              { view:'faculty',    icon:'👥', bg:'var(--blue-soft)',   title:'Faculty Management',   desc:'Remind incharges, escalate & assign jobs within your branch' },
              { view:'accounts',   icon:'➕', bg:'var(--green-soft)',  title:'Manage Accounts',      desc:'Add or edit student & incharge accounts in your department' },
              { view:'profile',    icon:'✏️', bg:'var(--yellow-soft)', title:'Edit My Profile',      desc:'Update your display name or password' },
            ].map(item => (
              <div key={item.view} className="card action-card card-clickable" onClick={() => onNavigate(item.view)}>
                <div className="action-card-icon" style={{ background: item.bg }}>{item.icon}</div>
                <h3>{item.title}</h3>
                <p>{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </main>
  );
}

/* ---- ALL COMPLAINTS ---- */
function AllComplaints({ user, onBack, showToast }) {
  const [filter, setFilter] = useState('all');
  const [selectedIds, setSelectedIds] = useState(new Set());
  const [lightboxSrc, setLightboxSrc] = useState(null);
  const [, forceUpdate] = useState(0);
  const refresh = () => { forceUpdate(n => n + 1); setSelectedIds(new Set()); };

  let all = Complaints.forBranch(user.branch).slice().sort((a,b) => {
    const o = {pending:0,accepted:1,working:2,solved:3,rejected:4};
    return (o[a.status]||0)-(o[b.status]||0);
  });
  if (filter === 'unaccepted') all = all.filter(c => c.status === 'pending' && !c.inchargeUsername);
  else if (filter !== 'all')   all = all.filter(c => c.status === filter);

  const canDelete = ['solved','rejected','all'].includes(filter);
  const toggleSelect = (id, checked) => {
    setSelectedIds(prev => { const s = new Set(prev); checked ? s.add(id) : s.delete(id); return s; });
  };
  const deleteSingle = (id) => {
    if (!window.confirm('Delete this complaint permanently?')) return;
    Complaints.delete(id);
    showToast('Complaint deleted', 'success');
    refresh();
  };
  const deleteSelected = () => {
    if (!selectedIds.size) { showToast('No complaints selected', 'error'); return; }
    if (!window.confirm(`Permanently delete ${selectedIds.size} complaint(s)?`)) return;
    const list = Complaints.getAll().filter(c => !selectedIds.has(c.id));
    Complaints.save(list);
    showToast('Deleted successfully', 'success');
    refresh();
  };

  return (
    <main className="page-wrap">
      <BackBtn onClick={onBack} />
      <div className="page-header fade-up fade-up-1">
        <h1>Department Complaints 📋</h1>
        <p>Showing complaints for {user.branch} department only.</p>
      </div>
      <FilterBar filters={STATUS_FILTERS} active={filter} onChange={v => { setFilter(v); setSelectedIds(new Set()); }} />
      {canDelete && (
        <div style={{ marginBottom: '1rem' }}>
          <div className="bulk-bar">
            <span>{selectedIds.size > 0 ? `${selectedIds.size} complaint(s) selected` : 'Select solved/rejected complaints to delete'}</span>
            <div style={{ display:'flex', gap:'0.5rem', flexWrap:'wrap' }}>
              <button className="btn btn-ghost btn-sm" onClick={() => {
                const ids = new Set(all.filter(c=>c.status==='solved'||c.status==='rejected').map(c=>c.id));
                setSelectedIds(ids);
              }}>Select All</button>
              <button className="btn btn-ghost btn-sm" onClick={() => setSelectedIds(new Set())}>Clear</button>
              <button className="btn btn-red btn-sm" onClick={deleteSelected}>🗑️ Delete Selected</button>
            </div>
          </div>
        </div>
      )}
      <div className="fade-up fade-up-3">
        {!all.length
          ? <EmptyState icon="🔍" message="No complaints match this filter." />
          : all.map(c => {
            const isUrgent    = c.status === 'pending' && !c.inchargeUsername;
            const isDeletable = c.status === 'solved' || c.status === 'rejected';
            return (
              <div className={`hod-complaint-card${isUrgent ? ' urgent' : ''}`} key={c.id}>
                <div className="hod-complaint-header">
                  <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                    {isDeletable
                      ? <input type="checkbox" className="hod-select-checkbox" checked={selectedIds.has(c.id)} onChange={e => toggleSelect(c.id, e.target.checked)} />
                      : <div style={{ width:16 }}></div>
                    }
                    <div className="hod-complaint-title">{c.title}</div>
                  </div>
                  <StatusBadge status={c.status} />
                </div>
                <div className="hod-meta-row">
                  <span className="meta-chip">🎓 {c.studentName}</span>
                  <span className="meta-chip">📋 {c.rollNo}</span>
                  <span className="meta-chip">🏫 {c.class}</span>
                  <span className="meta-chip">📚 {c.course}</span>
                  <span className="meta-chip">📅 {c.createdAt}</span>
                </div>
                <div className="incharge-info">
                  <span>👨‍🏫 Incharge:</span>
                  {c.inchargeName ? <strong>{c.inchargeName}</strong> : <span className="no-incharge">⚠️ Not yet accepted by any incharge</span>}
                </div>
                {c.rejectReason && <div className="reject-reason-hod">⚠️ Rejection reason: {c.rejectReason}</div>}
                <p className="hod-complaint-desc">{c.description}</p>
                {c.photo && <>
                  <img src={c.photo} className="photo-thumb photo-thumb-clickable" style={{ display:'block', marginBottom:'0.7rem' }} onClick={() => setLightboxSrc(c.photo)} alt="evidence" />
                  <div style={{ fontSize:'0.71rem', color:'var(--text3)', marginBottom:'0.7rem' }}>🔍 Click to view full size</div>
                </>}
                <div className="activity-log">
                  <div className="activity-log-title">Activity Log</div>
                  {c.history.map((h,i) => <div className="activity-entry" key={i}>{h.time} — {h.note}</div>)}
                </div>
                <div style={{ display:'flex', gap:'0.5rem', flexWrap:'wrap', marginTop:'0.8rem', paddingTop:'0.8rem', borderTop:'1px solid var(--border)' }}>
                  {isUrgent && <>
                    <button className="btn btn-yellow btn-sm" onClick={() => showToast(`🔔 Reminder sent to incharge of ${c.class}`)}>🔔 Remind Incharge</button>
                  </>}
                  {isDeletable && <button className="btn btn-red btn-sm" onClick={() => deleteSingle(c.id)}>🗑️ Delete</button>}
                </div>
              </div>
            );
          })
        }
      </div>
      <Lightbox src={lightboxSrc} onClose={() => setLightboxSrc(null)} />
    </main>
  );
}

/* ---- FACULTY MANAGEMENT ---- */
function FacultyManagement({ user, onBack, showToast }) {
  const [escalateModal, setEscalateModal] = useState(null);  // { fromClass }
  const [assignModal, setAssignModal]     = useState(null);  // { fromClass }
  const [escalateTarget, setEscalateTarget] = useState('');
  const [assignTarget, setAssignTarget]     = useState('');
  const [, forceUpdate] = useState(0);
  const refresh = () => forceUpdate(n => n + 1);

  const incharges = Accounts.getIncharges().filter(ic => ic.branch === user.branch);

  const confirmEscalate = () => {
    if (!escalateTarget) { showToast('Please select an incharge', 'error'); return; }
    const targetIc = Accounts.getAll().find(a => a.username === escalateTarget);
    if (!targetIc) return;
    const { fromClass } = escalateModal;
    const all = Complaints.getAll(); let count = 0;
    const now = new Date().toLocaleString('en-IN', { dateStyle:'medium', timeStyle:'short' });
    all.forEach(c => {
      if (c.class === fromClass && c.status === 'pending') {
        c.class = targetIc.branch + '-' + targetIc.section;
        c.inchargeUsername = null; c.inchargeName = null;
        c.history.push({ status:'pending', note:`Escalated by HOD to ${targetIc.name}`, time:now }); count++;
      }
    });
    Complaints.save(all);
    setEscalateModal(null); setEscalateTarget('');
    showToast(`✅ ${count} complaint(s) escalated to ${targetIc.name}`, 'success');
    refresh();
  };

  const confirmAssign = () => {
    if (!assignTarget) { showToast('Please select an incharge', 'error'); return; }
    const allAccounts = Accounts.getAll();
    const targetIc = allAccounts.find(a => a.username === assignTarget);
    if (!targetIc) return;
    const { fromClass } = assignModal;
    const allComplaints = Complaints.getAll(); let count = 0;
    const now = new Date().toLocaleString('en-IN', { dateStyle:'medium', timeStyle:'short' });
    allComplaints.forEach(c => {
      if (c.class === fromClass && c.status !== 'solved' && c.status !== 'rejected') {
        c.class = targetIc.branch + '-' + targetIc.section;
        c.history.push({ status:c.status, note:`Job assigned by HOD — ${fromClass} duties covered by ${targetIc.name}`, time:now }); count++;
      }
    });
    const idx = allAccounts.findIndex(a => a.username === assignTarget);
    if (idx !== -1) { allAccounts[idx].assignedFrom = fromClass; }
    Accounts.save(allAccounts); Complaints.save(allComplaints);
    setAssignModal(null); setAssignTarget('');
    showToast(`✅ ${count} complaint(s) from ${fromClass} assigned to ${targetIc.name}`, 'success');
    refresh();
  };

  const endAssignment = (targetUsername) => {
    const allAccounts = Accounts.getAll();
    const targetIc = allAccounts.find(a => a.username === targetUsername);
    if (!targetIc || !targetIc.assignedFrom) { showToast('No active assignment to end', 'error'); return; }
    const originalClass = targetIc.assignedFrom;
    const allComplaints = Complaints.getAll();
    const now = new Date().toLocaleString('en-IN', { dateStyle:'medium', timeStyle:'short' });
    allComplaints.forEach(c => {
      if (c.class === targetIc.branch + '-' + targetIc.section && c.status !== 'solved' && c.status !== 'rejected') {
        c.class = originalClass;
        c.history.push({ status:c.status, note:`Assignment ended by HOD — returned to ${originalClass}`, time:now });
      }
    });
    const idx = allAccounts.findIndex(a => a.username === targetUsername);
    if (idx !== -1) { delete allAccounts[idx].assignedFrom; }
    Accounts.save(allAccounts); Complaints.save(allComplaints);
    showToast(`✅ Assignment ended — complaints returned to ${originalClass}`, 'success');
    refresh();
  };

  return (
    <main className="page-wrap">
      <BackBtn onClick={onBack} />
      <div className="page-header fade-up fade-up-1">
        <h1>Faculty Management 👥</h1>
        <p>Remind incharges, escalate unresolved complaints, and assign jobs — within your department.</p>
      </div>
      <div className="fade-up fade-up-2">
        {!incharges.length
          ? <EmptyState icon="👥" message={`No incharges found for ${user.branch} department.`} />
          : incharges.map(ic => {
            const cls     = ic.branch + '-' + ic.section;
            const icAll   = Complaints.forClass(ic.branch, ic.section);
            const pending = icAll.filter(c=>c.status==='pending').length;
            const accepted= icAll.filter(c=>c.status==='accepted').length;
            const working = icAll.filter(c=>c.status==='working').length;
            const solved  = icAll.filter(c=>c.status==='solved').length;
            return (
              <div className="faculty-mgmt-card" key={ic.username}>
                <div className="faculty-mgmt-header">
                  <div>
                    <div className="faculty-mgmt-name">👨‍🏫 {ic.name} {ic.assignedFrom && <span className="assign-tag">📋 Currently covering {ic.assignedFrom}</span>}</div>
                    <div style={{ fontSize:'0.82rem', color:'var(--text2)', marginTop:2 }}>Class: <strong>{cls}</strong> · Username: <code style={{ background:'var(--surface2)', padding:'1px 5px', borderRadius:3, fontSize:'0.75rem' }}>{ic.username}</code></div>
                  </div>
                  <span className={`badge ${pending>0?'badge-pending':'badge-solved'}`}>{pending>0?`${pending} pending`:'All resolved'}</span>
                </div>
                <div className="faculty-mgmt-stats">
                  <div className="fstat">📋 Total: <strong>{icAll.length}</strong></div>
                  <div className="fstat">⏳ Pending: <strong>{pending}</strong></div>
                  <div className="fstat">📌 Accepted: <strong>{accepted}</strong></div>
                  <div className="fstat">🔧 Working: <strong>{working}</strong></div>
                  <div className="fstat">✅ Solved: <strong>{solved}</strong></div>
                </div>
                <div className="faculty-mgmt-actions">
                  {pending > 0 && <>
                    <button className="btn btn-yellow btn-sm" onClick={() => showToast(`🔔 Reminder sent to ${ic.name}`)}>🔔 Send Reminder</button>
                    <button className="btn btn-red btn-sm" onClick={() => { setEscalateModal({ fromClass:cls }); setEscalateTarget(''); }}>🔁 Escalate Pending</button>
                  </>}
                  {(accepted>0||working>0) && <button className="btn btn-blue btn-sm" onClick={() => showToast(`⚡ Reminder sent to ${ic.name}`)}>⚡ Remind to Complete</button>}
                  <button className="btn btn-blue btn-sm" onClick={() => { setAssignModal({ fromClass:cls }); setAssignTarget(''); }}>📋 Assign Job to Another</button>
                  {ic.assignedFrom && <button className="btn btn-green btn-sm" onClick={() => endAssignment(ic.username)}>🔄 End Assignment</button>}
                  {pending===0&&accepted===0&&working===0 && <span style={{ fontSize:'0.82rem', color:'var(--green)' }}>✅ Fully up to date</span>}
                </div>
              </div>
            );
          })
        }
      </div>

      {/* Escalate Modal */}
      <Modal open={!!escalateModal} onClose={() => setEscalateModal(null)} title="🔁 Escalate Complaints"
        subtitle={`Reassign unaccepted complaints from ${escalateModal?.fromClass} to another incharge`}
        footer={<>
          <button className="btn btn-ghost" onClick={() => setEscalateModal(null)}>Cancel</button>
          <button className="btn btn-primary btn-full" onClick={confirmEscalate}>Escalate →</button>
        </>}
      >
        <p style={{ fontSize:'0.85rem', color:'var(--text2)', marginBottom:'0.8rem' }}>Select an incharge to take over:</p>
        {incharges.filter(ic => ic.branch+'-'+ic.section !== escalateModal?.fromClass).map(ic => (
          <label key={ic.username} className={`escalate-option${escalateTarget===ic.username?' selected':''}`}>
            <input type="radio" name="escalate-target" value={ic.username} checked={escalateTarget===ic.username} onChange={() => setEscalateTarget(ic.username)} />
            <div><div style={{ fontWeight:600, fontSize:'0.92rem' }}>{ic.name}</div><div style={{ fontSize:'0.78rem', color:'var(--text2)' }}>{ic.branch}-{ic.section}</div></div>
          </label>
        ))}
      </Modal>

      {/* Assign Modal */}
      <Modal open={!!assignModal} onClose={() => setAssignModal(null)} title="📋 Assign Job to Incharge"
        subtitle={`Assign complaints from ${assignModal?.fromClass} to another incharge`}
        footer={<>
          <button className="btn btn-ghost" onClick={() => setAssignModal(null)}>Cancel</button>
          <button className="btn btn-blue btn-full" onClick={confirmAssign}>Assign Job →</button>
        </>}
      >
        <div style={{ background:'var(--blue-soft)', border:'1px solid var(--blue)', borderRadius:6, padding:'8px 12px', fontSize:'0.82rem', color:'var(--blue)', marginBottom:'0.8rem' }}>
          📌 This will route all active complaints from <strong>{assignModal?.fromClass}</strong> to the selected incharge temporarily.
        </div>
        {incharges.filter(ic => ic.branch+'-'+ic.section !== assignModal?.fromClass).map(ic => {
          const icAll = Complaints.forClass(ic.branch, ic.section);
          return (
            <label key={ic.username} className={`assign-option${assignTarget===ic.username?' selected':''}`}>
              <input type="radio" name="assign-target" value={ic.username} checked={assignTarget===ic.username} onChange={() => setAssignTarget(ic.username)} />
              <div style={{ flex:1 }}>
                <div style={{ fontWeight:600, fontSize:'0.92rem' }}>{ic.name}</div>
                <div style={{ fontSize:'0.78rem', color:'var(--text2)' }}>{ic.branch}-{ic.section} · {icAll.length} existing complaints</div>
              </div>
            </label>
          );
        })}
      </Modal>
    </main>
  );
}

/* ---- ACCOUNTS ---- */
function AccountsView({ user, onBack, showToast }) {
  const [newRole, setNewRole] = useState('incharge');
  const [form, setForm] = useState({ name:'', username:'', password:'', section:'', course:'', rollNo:'' });
  const [editUsername, setEditUsername] = useState(null);
  const [editForm, setEditForm] = useState({});
  const [, forceUpdate] = useState(0);
  const refresh = () => forceUpdate(n => n + 1);
  const setF = (k,v) => setForm(f => ({...f,[k]:v}));

  const createAccount = () => {
    if (!form.name || !form.username || !form.password) { showToast('Name, username, and password are required', 'error'); return; }
    if (form.password.length < 4) { showToast('Password must be at least 4 characters', 'error'); return; }
    if (Accounts.usernameExists(form.username)) { showToast('Username already exists', 'error'); return; }
    let acc = { role:newRole, name:form.name, username:form.username, password:form.password, branch:user.branch };
    if (newRole === 'incharge') {
      if (!form.section) { showToast('Select a section', 'error'); return; }
      acc.section = form.section;
    } else {
      if (!form.section || !form.course || !form.rollNo) { showToast('All student fields are required', 'error'); return; }
      acc.section = form.section; acc.course = form.course; acc.rollNo = form.rollNo;
    }
    Accounts.add(acc);
    setForm({ name:'', username:'', password:'', section:'', course:'', rollNo:'' });
    showToast(`✅ Account created for ${form.name}`, 'success');
    refresh();
  };

  const openEdit = (username) => {
    const u = Accounts.findByUsername(username);
    setEditUsername(username);
    setEditForm({ name:u.name||'', section:u.section||'', course:u.course||'', rollNo:u.rollNo||'', password:'' });
  };

  const confirmEdit = () => {
    const u = Accounts.findByUsername(editUsername);
    if (!editForm.name) { showToast('Name is required', 'error'); return; }
    if (editForm.password && editForm.password.length < 4) { showToast('Password must be at least 4 characters', 'error'); return; }
    const updates = { name:editForm.name };
    if (editForm.password) updates.password = editForm.password;
    if (u.role === 'incharge' || u.role === 'student') {
      if (!editForm.section) { showToast('Section is required', 'error'); return; }
      updates.section = editForm.section;
    }
    if (u.role === 'student') {
      if (!editForm.course || !editForm.rollNo) { showToast('Course and roll number are required', 'error'); return; }
      updates.course = editForm.course; updates.rollNo = editForm.rollNo;
    }
    Accounts.update(editUsername, updates);
    setEditUsername(null);
    showToast('✅ Account updated successfully', 'success');
    refresh();
  };

  const sorted = [
    ...Accounts.getIncharges().filter(a => a.branch === user.branch),
    ...Accounts.getStudents().filter(a => a.branch === user.branch),
  ];

  return (
    <main className="page-wrap">
      <BackBtn onClick={onBack} />
      <div className="page-header fade-up fade-up-1"><h1>Manage Accounts ➕</h1><p>Add or edit student and incharge accounts within your department.</p></div>
      <div className="grid grid-2 fade-up fade-up-2" style={{ alignItems:'flex-start' }}>
        <div className="card">
          <div className="section-title">New Account</div>
          <div className="form-group"><label>Account Type *</label>
            <select value={newRole} onChange={e => setNewRole(e.target.value)}>
              <option value="incharge">Incharge / Faculty</option>
              <option value="student">Student</option>
            </select>
          </div>
          <div className="form-group"><label>Full Name *</label><input type="text" value={form.name} onChange={e => setF('name',e.target.value)} placeholder="Full name" /></div>
          <div className="form-group"><label>Username *</label><input type="text" value={form.username} onChange={e => setF('username',e.target.value)} placeholder="Unique login username" /></div>
          <div className="form-group"><label>Password *</label><input type="password" value={form.password} onChange={e => setF('password',e.target.value)} placeholder="Set a password" /></div>
          <div className="form-row">
            <div className="form-group"><label>Branch</label><input type="text" value={user.branch} readOnly style={{ background:'var(--surface2)', color:'var(--text2)' }} /></div>
            <div className="form-group"><label>Section *</label>
              <select value={form.section} onChange={e => setF('section',e.target.value)}>
                <option value="">Select</option>{['A','B','C','D'].map(s=><option key={s}>{s}</option>)}
              </select>
            </div>
          </div>
          {newRole === 'student' && <>
            <div className="form-group"><label>Course *</label>
              <select value={form.course} onChange={e => setF('course',e.target.value)}>
                <option value="">Select</option>{['B.Tech','M.Tech','MBA','MCA','BCA','B.Sc'].map(c=><option key={c}>{c}</option>)}
              </select>
            </div>
            <div className="form-group"><label>Roll Number *</label><input type="text" value={form.rollNo} onChange={e => setF('rollNo',e.target.value)} placeholder="e.g. 22CSM001" /></div>
          </>}
          <button className="btn btn-primary btn-full" style={{ marginTop:'0.5rem' }} onClick={createAccount}>➕ Create Account</button>
        </div>
        <div>
          <div className="section-title">Department Accounts</div>
          {!sorted.length
            ? <div className="empty-state"><p>No accounts in {user.branch} department yet.</p></div>
            : sorted.map(a => (
              <div className="account-item" key={a.username}>
                <div className="account-item-icon" style={{ background: a.role==='incharge'?'var(--blue-soft)':'var(--accent-soft)' }}>{a.role==='incharge'?'👨‍🏫':'🎓'}</div>
                <div className="account-item-info">
                  <strong>{a.name}</strong>
                  <span>{a.branch}-{a.section}{a.role==='student'?' · '+(a.rollNo||''):''} · {a.username}</span>
                </div>
                <span className={`account-item-role ${a.role==='incharge'?'role-incharge':'role-student'}`}>{a.role==='incharge'?'Incharge':'Student'}</span>
                <button className="btn btn-ghost btn-xs" style={{ marginLeft:'0.4rem' }} onClick={() => openEdit(a.username)}>✏️</button>
              </div>
            ))
          }
        </div>
      </div>

      {/* Edit Account Modal */}
      {editUsername && (() => {
        const u = Accounts.findByUsername(editUsername);
        return (
          <Modal open onClose={() => setEditUsername(null)} title={`✏️ Edit — ${u.name}`} subtitle="Update bio details. Username cannot be changed."
            footer={<>
              <button className="btn btn-ghost" onClick={() => setEditUsername(null)}>Cancel</button>
              <button className="btn btn-primary btn-full" onClick={confirmEdit}>💾 Save Changes</button>
            </>}
          >
            <div className="form-group"><label>Full Name *</label><input type="text" value={editForm.name} onChange={e => setEditForm(f=>({...f,name:e.target.value}))} placeholder="Full name" /></div>
            {(u.role==='incharge'||u.role==='student') && (
              <div className="form-row">
                <div className="form-group"><label>Branch</label><input type="text" value={u.branch||''} readOnly style={{ background:'var(--surface2)' }} /></div>
                <div className="form-group"><label>Section *</label>
                  <select value={editForm.section} onChange={e => setEditForm(f=>({...f,section:e.target.value}))}>
                    <option value="">Select</option>{['A','B','C','D'].map(s=><option key={s}>{s}</option>)}
                  </select>
                </div>
              </div>
            )}
            {u.role==='student' && <>
              <div className="form-group"><label>Course *</label>
                <select value={editForm.course} onChange={e => setEditForm(f=>({...f,course:e.target.value}))}>
                  <option value="">Select</option>{['B.Tech','M.Tech','MBA','MCA','BCA','B.Sc'].map(c=><option key={c}>{c}</option>)}
                </select>
              </div>
              <div className="form-group"><label>Roll Number *</label><input type="text" value={editForm.rollNo} onChange={e => setEditForm(f=>({...f,rollNo:e.target.value}))} /></div>
            </>}
            <div className="form-group"><label>New Password <span style={{ color:'var(--text3)', fontSize:'0.78rem' }}>(leave blank to keep current)</span></label>
              <input type="password" value={editForm.password} onChange={e => setEditForm(f=>({...f,password:e.target.value}))} placeholder="Set new password" />
            </div>
          </Modal>
        );
      })()}
    </main>
  );
}

/* ---- PROFILE ---- */
function ProfileModal({ user, onClose, showToast, refreshUser }) {
  const u = Accounts.findByUsername(user.username);
  const [name, setName] = useState(u.name||'');
  const [password, setPassword] = useState('');
  const save = () => {
    if (!name) { showToast('Name is required', 'error'); return; }
    if (password && password.length < 4) { showToast('Password must be at least 4 characters', 'error'); return; }
    const updates = { name }; if (password) updates.password = password;
    Accounts.update(user.username, updates);
    refreshUser();
    onClose();
    showToast('✅ Profile updated!', 'success');
  };
  return (
    <Modal open onClose={onClose} title="✏️ Edit My Profile" subtitle="Update your name or password."
      footer={<>
        <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
        <button className="btn btn-primary btn-full" onClick={save}>💾 Save Changes</button>
      </>}
    >
      <div className="form-group"><label>Full Name *</label><input type="text" value={name} onChange={e => setName(e.target.value)} /></div>
      <div className="form-group"><label>New Password <span style={{ color:'var(--text3)', fontSize:'0.78rem' }}>(leave blank to keep current)</span></label>
        <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Enter new password" />
      </div>
    </Modal>
  );
}

/* ---- MAIN ---- */
export default function HODPage() {
  const { currentUser, showToast, refreshUser } = useApp();
  const [view, setView] = useState('dashboard');
  const [showProfile, setShowProfile] = useState(false);
  const nav = useCallback(v => {
    if (v === 'profile') { setShowProfile(true); return; }
    setView(v); window.scrollTo({ top:0, behavior:'smooth' });
  }, []);

  return (
    <>
      <Header onLogoClick={() => nav('dashboard')} />
      {view === 'dashboard'  && <Dashboard user={currentUser} onNavigate={nav} />}
      {view === 'complaints' && <AllComplaints user={currentUser} onBack={() => nav('dashboard')} showToast={showToast} />}
      {view === 'faculty'    && <FacultyManagement user={currentUser} onBack={() => nav('dashboard')} showToast={showToast} />}
      {view === 'accounts'   && <AccountsView user={currentUser} onBack={() => nav('dashboard')} showToast={showToast} />}
      {showProfile && <ProfileModal user={currentUser} onClose={() => setShowProfile(false)} showToast={showToast} refreshUser={refreshUser} />}
      <Footer />
      <Toast />
    </>
  );
}
