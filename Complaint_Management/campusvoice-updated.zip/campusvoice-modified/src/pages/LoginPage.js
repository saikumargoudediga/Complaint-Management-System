import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Accounts } from '../utils/storage';
import { LoginHeader, Footer, Toast, Modal } from '../components/Shared';

const MODAL_CONFIG = {
  student:  { title: '🎓 Student Login',        sub: 'Enter your credentials to access your dashboard',         hint: 'Demo: student1 / 1234  or  student2 / 1234' },
  incharge: { title: '👨‍🏫 Class Incharge Login', sub: 'Login to manage complaints for your class',               hint: 'Demo: ic_csma / 1234  or  ic_eceb / 1234' },
  hod:      { title: '🏛️ HOD Login',             sub: "Access your department's complaints and faculty",          hint: 'Demo: hod_csm / hod123  or  hod_ece / hod123' },
  admin:    { title: '🔐 Admin Login',           sub: 'Full system access across all departments',                hint: 'Demo: admin / admin123' },
};

export default function LoginPage({ onLogin }) {
  const { login, showToast } = useApp();
  const [activeRole, setActiveRole] = useState(null);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const openModal = (role) => {
    setActiveRole(role);
    setUsername('');
    setPassword('');
  };
  const closeModal = () => setActiveRole(null);

  const doLogin = () => {
    if (!username.trim() || !password.trim()) {
      showToast('Please enter both username and password', 'error'); return;
    }
    const user = Accounts.find(username.trim(), password.trim(), activeRole);
    if (!user) { showToast('Invalid credentials. Check the demo hint!', 'error'); return; }
    login(user);
    showToast(`Welcome, ${user.name}! 👋`, 'success');
    setTimeout(() => onLogin(user), 700);
  };

  const cfg = activeRole ? MODAL_CONFIG[activeRole] : null;

  return (
    <>
      <LoginHeader />
      <main className="login-main">
        <div className="login-hero fade-up">
          <div className="hero-badge">🎓 College Complaint Portal</div>
          <h1>Raise Your <em>Voice.</em><br />Get It <span>Resolved.</span></h1>
          <p>CampusVoice — transparent, encrypted, and built for every student, incharge, HOD, and administrator.</p>
        </div>

        <div className="login-cards fade-up fade-up-2">
          <div className="login-card" onClick={() => openModal('student')}>
            <div className="lcard-accent"></div>
            <div className="lcard-icon" style={{ background: 'var(--accent-soft)' }}>🎓</div>
            <div className="lcard-body"><h3>Student</h3><p>Raise complaints &amp; track their resolution in real time</p></div>
            <div className="lcard-arrow">→</div>
          </div>
          <div className="login-card" onClick={() => openModal('incharge')}>
            <div className="lcard-accent" style={{ background: 'var(--blue)' }}></div>
            <div className="lcard-icon" style={{ background: 'var(--blue-soft)' }}>👨‍🏫</div>
            <div className="lcard-body"><h3>Class Incharge</h3><p>Manage and resolve complaints from your assigned class</p></div>
            <div className="lcard-arrow">→</div>
          </div>
          <div className="login-card" onClick={() => openModal('hod')}>
            <div className="lcard-accent" style={{ background: 'var(--green)' }}></div>
            <div className="lcard-icon" style={{ background: 'var(--green-soft)' }}>🏛️</div>
            <div className="lcard-body"><h3>Head of Department</h3><p>Manage complaints &amp; faculty within your department only</p></div>
            <div className="lcard-arrow">→</div>
          </div>
          <div className="login-card" onClick={() => openModal('admin')}>
            <div className="lcard-accent" style={{ background: 'var(--yellow)' }}></div>
            <div className="lcard-icon" style={{ background: 'var(--yellow-soft)' }}>🔐</div>
            <div className="lcard-body"><h3>Admin</h3><p>Full oversight — all departments, pending stats &amp; analytics</p></div>
            <div className="lcard-arrow">→</div>
          </div>
        </div>

        <div className="login-features fade-up fade-up-3">
          <div className="feature-pill">🔒 End-to-End Encrypted</div>
          <div className="feature-pill">💾 Persistent Data</div>
          <div className="feature-pill">📱 Mobile Friendly</div>
          <div className="feature-pill">⚡ Real-time Status</div>
        </div>
      </main>

      {cfg && (
        <Modal
          open={!!activeRole}
          onClose={closeModal}
          title={cfg.title}
          subtitle={cfg.sub}
          footer={
            <>
              <button className="btn btn-ghost" onClick={closeModal}>Cancel</button>
              <button className="btn btn-primary btn-full" onClick={doLogin}>Login →</button>
            </>
          }
        >
          <div className="demo-hint">💡 {cfg.hint}</div>
          <div className="form-group">
            <label>Username</label>
            <input type="text" value={username} onChange={e => setUsername(e.target.value)} placeholder="Enter username" autoComplete="username" autoFocus />
          </div>
          <div className="form-group">
            <label>Password</label>
            <input
              type="password" value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="Enter password"
              autoComplete="current-password"
              onKeyDown={e => { if (e.key === 'Enter') doLogin(); }}
            />
          </div>
        </Modal>
      )}

      <Footer />
      <Toast />
    </>
  );
}
