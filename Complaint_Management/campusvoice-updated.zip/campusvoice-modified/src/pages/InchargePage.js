import React, { useState, useCallback } from 'react';
import { useApp } from '../context/AppContext';
import { Complaints, Accounts, FACULTY_EVENTS } from '../utils/storage';
import { Header, Footer, Toast, EventsBanner, StatusBadge, BackBtn, EmptyState, FilterBar, Modal, Lightbox } from '../components/Shared';

const STATUS_FILTERS = [
  { value: 'all', label: 'All' },
  { value: 'pending', label: '⏳ Pending' },
  { value: 'accepted', label: '📌 Accepted' },
  { value: 'working', label: '🔧 Working' },
  { value: 'solved', label: '✅ Solved' },
  { value: 'rejected', label: '❌ Rejected' },
];

function Dashboard({ user, onNavigate }) {
  const cls = user.branch + '-' + user.section;
  const complaints = Complaints.forClass(user.branch, user.section);
  const pending = complaints.filter(c => c.status === 'pending').length;
  const inprog  = complaints.filter(c => c.status === 'accepted' || c.status === 'working').length;
  const solved  = complaints.filter(c => c.status === 'solved').length;

  return (
    <main className="page-wrap">
      <div className="page-header fade-up">
        <h1>Incharge Dashboard 👨‍🏫</h1>
        <p>{user.name} — Class: {cls}</p>
      </div>
      <EventsBanner events={FACULTY_EVENTS} />
      <div className="section-title fade-up fade-up-2">Class Overview</div>
      <div className="grid grid-3 fade-up fade-up-2" style={{ marginBottom: '2rem' }}>
        <div className="card stat-card"><div className="stat-icon" style={{ background: 'var(--red-soft)' }}>🔴</div><div><h3>{pending}</h3><p>Pending</p></div></div>
        <div className="card stat-card"><div className="stat-icon" style={{ background: 'var(--blue-soft)' }}>🔧</div><div><h3>{inprog}</h3><p>In Progress</p></div></div>
        <div className="card stat-card"><div className="stat-icon" style={{ background: 'var(--green-soft)' }}>✅</div><div><h3>{solved}</h3><p>Resolved</p></div></div>
      </div>
      <div className="section-title fade-up fade-up-3">Manage</div>
      <div className="grid grid-2 fade-up fade-up-3">
        <div className="card action-card card-clickable" style={{ position: 'relative' }} onClick={() => onNavigate('manage')}>
          <div className="action-card-icon" style={{ background: 'var(--blue-soft)' }}>📂</div>
          <h3>Manage Complaints</h3>
          <p>View, accept, and resolve complaints from your class</p>
          {pending > 0 && <>
            <div className="notif-dot"></div>
            <div className="count-chip">{pending} new</div>
          </>}
        </div>
        <div className="card action-card card-clickable" onClick={() => onNavigate('profile')}>
          <div className="action-card-icon" style={{ background: 'var(--green-soft)' }}>✏️</div>
          <h3>Edit My Profile</h3>
          <p>Update your name or password. Class assignment is managed by HOD.</p>
        </div>
        <div className="card action-card" style={{ cursor: 'default', gridColumn: '1/-1' }}>
          <div className="action-card-icon" style={{ background: 'var(--accent-soft)' }}>🔒</div>
          <h3>Privacy Guaranteed</h3>
          <p>You only see complaints from your assigned class. All data is encrypted.</p>
        </div>
      </div>
    </main>
  );
}

function ManageComplaints({ user, onBack, showToast }) {
  const [filter, setFilter] = useState('all');
  const [rejectId, setRejectId] = useState(null);
  const [rejectReason, setRejectReason] = useState('');
  const [lightboxSrc, setLightboxSrc] = useState(null);
  const [, forceUpdate] = useState(0);
  const refresh = () => forceUpdate(n => n + 1);

  const cls = user.branch + '-' + user.section;

  let complaints = Complaints.forClass(user.branch, user.section);
  complaints.sort((a, b) => {
    const o = { pending:0, accepted:1, working:2, solved:3, rejected:4 };
    return (o[a.status]||0) - (o[b.status]||0);
  });
  if (filter !== 'all') complaints = complaints.filter(c => c.status === filter);

  const updateStatus = (id, newStatus) => {
    const notes = {
      accepted: `Complaint accepted by ${user.name}`,
      working:  `${user.name} is actively working on the complaint`,
      solved:   `Complaint marked as resolved by ${user.name}`,
    };
    Complaints.updateStatus(id, newStatus, user, notes[newStatus]);
    showToast(`Status updated`, 'success');
    refresh();
  };

  const confirmReject = () => {
    if (!rejectReason.trim()) { showToast('Please enter a reason for rejection', 'error'); return; }
    const list = Complaints.getAll();
    const idx  = list.findIndex(c => c.id === rejectId);
    if (idx === -1) return;
    list[idx].status = 'rejected';
    list[idx].rejectReason = rejectReason;
    list[idx].inchargeUsername = user.username;
    list[idx].inchargeName    = user.name;
    const now = new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' });
    list[idx].history.push({ status: 'rejected', note: `Rejected by ${user.name} — Reason: ${rejectReason}`, time: now });
    Complaints.save(list);
    setRejectId(null); setRejectReason('');
    showToast('Complaint rejected', 'error');
    refresh();
  };

  return (
    <main className="page-wrap">
      <BackBtn onClick={onBack} />
      <div className="page-header fade-up fade-up-1">
        <h1>Manage Complaints 📂</h1>
        <p>Complaints for {cls} — {user.name}</p>
      </div>

      <FilterBar filters={STATUS_FILTERS} active={filter} onChange={setFilter} />

      <div className="fade-up fade-up-3">
        {!complaints.length
          ? <EmptyState icon={filter === 'all' ? '🎉' : '🔍'} message={filter === 'all' ? 'No complaints for your class yet.' : `No <b>${filter}</b> complaints.`} />
          : complaints.map(c => {
            const isPending = c.status === 'pending';
            const isAccepted = c.status === 'accepted';
            const isWorking = c.status === 'working';
            const isSolved = c.status === 'solved';
            const isRejected = c.status === 'rejected';

            return (
              <div className="complaint-card" key={c.id}>
                <div className="encrypted-tag">🔒 End-to-end encrypted — visible only to you and the student</div>
                <div className="ic-complaint-header">
                  <div>
                    <div className="complaint-title">{c.title}</div>
                    <div className="complaint-chips" style={{ marginTop: 5 }}>
                      <span className="meta-chip">🏫 {c.class}</span>
                      <span className="meta-chip">📅 {c.createdAt}</span>
                    </div>
                  </div>
                  <StatusBadge status={c.status} />
                </div>
                <div className="student-detail-row">
                  <span>👤 <strong>{c.studentName}</strong></span>
                  <span className="meta-chip">📋 {c.rollNo}</span>
                  <span className="meta-chip">📞 {c.phone}</span>
                  <span className="meta-chip">📚 {c.course}</span>
                </div>
                {isRejected && c.rejectReason && <div className="reject-reason">⚠️ Rejection reason: {c.rejectReason}</div>}
                <p className="complaint-desc">{c.description}</p>
                {c.photo && <>
                  <img src={c.photo} className="photo-thumb photo-thumb-clickable" style={{ display:'block', marginBottom:'0.8rem' }} onClick={() => setLightboxSrc(c.photo)} alt="evidence" />
                  <div style={{ fontSize:'0.72rem', color:'var(--text3)', marginTop:'-0.5rem', marginBottom:'0.8rem' }}>🔍 Click photo to view full size</div>
                </>}
                <div className="activity-log">
                  <div className="activity-log-title">Activity Log</div>
                  {c.history.map((h, i) => <div className="activity-entry" key={i}>{h.time} — {h.note}</div>)}
                </div>
                <div className="status-actions-row">
                  {isPending && <>
                    <span>Action required:</span>
                    <button className="btn btn-primary btn-sm" onClick={() => updateStatus(c.id, 'accepted')}>✅ Accept Complaint</button>
                    <button className="btn btn-red btn-sm" onClick={() => { setRejectId(c.id); setRejectReason(''); }}>❌ Reject</button>
                  </>}
                  {isAccepted && <>
                    <span>Next step:</span>
                    <button className="btn btn-blue btn-sm" onClick={() => updateStatus(c.id, 'working')}>🔧 Mark as Working</button>
                    <button className="btn btn-green btn-sm" onClick={() => updateStatus(c.id, 'solved')}>🎉 Mark Solved</button>
                    <button className="btn btn-red btn-sm" onClick={() => { setRejectId(c.id); setRejectReason(''); }}>❌ Reject</button>
                  </>}
                  {isWorking && <>
                    <span>In progress:</span>
                    <button className="btn btn-green btn-sm" onClick={() => updateStatus(c.id, 'solved')}>🎉 Mark Solved</button>
                    <button className="btn btn-red btn-sm" onClick={() => { setRejectId(c.id); setRejectReason(''); }}>❌ Reject</button>
                  </>}
                  {isSolved && <div className="resolved-banner">✅ Resolved by you</div>}
                  {isRejected && <div className="rejected-banner">❌ Rejected</div>}
                </div>
              </div>
            );
          })
        }
      </div>

      <Modal open={!!rejectId} onClose={() => setRejectId(null)} title="❌ Reject Complaint" subtitle="Provide a clear reason so the student understands."
        footer={<>
          <button className="btn btn-ghost" onClick={() => setRejectId(null)}>Cancel</button>
          <button className="btn btn-red btn-full" onClick={confirmReject}>❌ Confirm Rejection</button>
        </>}
      >
        <div className="form-group">
          <label>Reason for Rejection *</label>
          <textarea value={rejectReason} onChange={e => setRejectReason(e.target.value)} placeholder="e.g. Complaint does not fall under this department…" style={{ minHeight: 100 }} />
        </div>
      </Modal>

      <Lightbox src={lightboxSrc} onClose={() => setLightboxSrc(null)} />
    </main>
  );
}

function ProfileView({ user, onBack, showToast, refreshUser }) {
  const u = Accounts.findByUsername(user.username);
  const [name, setName] = useState(u.name || '');
  const [password, setPassword] = useState('');

  const save = () => {
    if (!name) { showToast('Name is required', 'error'); return; }
    if (password && password.length < 4) { showToast('Password must be at least 4 characters', 'error'); return; }
    const updates = { name };
    if (password) updates.password = password;
    Accounts.update(user.username, updates);
    refreshUser();
    showToast('✅ Profile updated!', 'success');
    onBack();
  };

  return (
    <main className="page-wrap">
      <BackBtn onClick={onBack} />
      <div className="page-header fade-up fade-up-1"><h1>Edit My Profile ✏️</h1><p>Update your display name or password. Class assignment is controlled by HOD/Admin.</p></div>
      <div className="card fade-up fade-up-2" style={{ maxWidth: 500 }}>
        <div className="form-group"><label>Full Name *</label><input type="text" value={name} onChange={e => setName(e.target.value)} /></div>
        <div className="form-group"><label>Assigned Class <span style={{ color: 'var(--text3)', fontSize: '0.78rem' }}>🔒 Managed by HOD</span></label>
          <div style={{ padding: '10px 14px', background: 'var(--surface2)', borderRadius: 8, fontWeight: 600, color: 'var(--text2)', border: '1px solid var(--border)' }}>{u.branch}-{u.section}</div>
        </div>
        <div className="form-group"><label>New Password <span style={{ color: 'var(--text3)', fontSize: '0.78rem' }}>(leave blank to keep current)</span></label><input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Enter new password" /></div>
        <div className="form-actions">
          <button className="btn btn-ghost" onClick={onBack}>Cancel</button>
          <button className="btn btn-primary" onClick={save}>💾 Save Changes</button>
        </div>
      </div>
    </main>
  );
}

export default function InchargePage() {
  const { currentUser, showToast, refreshUser } = useApp();
  const [view, setView] = useState('dashboard');
  const nav = useCallback(v => { setView(v); window.scrollTo({ top: 0, behavior: 'smooth' }); }, []);

  return (
    <>
      <Header onLogoClick={() => nav('dashboard')} />
      {view === 'dashboard' && <Dashboard user={currentUser} onNavigate={nav} />}
      {view === 'manage'    && <ManageComplaints user={currentUser} onBack={() => nav('dashboard')} showToast={showToast} />}
      {view === 'profile'   && <ProfileView user={currentUser} onBack={() => nav('dashboard')} showToast={showToast} refreshUser={refreshUser} />}
      <Footer />
      <Toast />
    </>
  );
}
