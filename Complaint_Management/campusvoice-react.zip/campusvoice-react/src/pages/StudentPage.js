import React, { useState, useCallback } from 'react';
import { useApp } from '../context/AppContext';
import { Complaints, Accounts, genId, CAMPUS_EVENTS } from '../utils/storage';
import { Header, Footer, Toast, EventsBanner, ComplaintCard, BackBtn, EmptyState } from '../components/Shared';

function Dashboard({ user, onNavigate }) {
  const complaints = Complaints.forStudent(user.username);
  const total   = complaints.length;
  const solved  = complaints.filter(c => c.status === 'solved').length;
  const pending = complaints.filter(c => c.status !== 'solved').length;

  return (
    <main className="page-wrap">
      <div className="page-header fade-up">
        <h1>Welcome back, <span>{user.name.split(' ')[0]}</span> 👋</h1>
        <p>Your personal complaint portal — secure, transparent, and always up to date.</p>
      </div>

      <EventsBanner events={CAMPUS_EVENTS} />

      <div className="section-title fade-up fade-up-2">My Overview</div>
      <div className="grid grid-3 fade-up fade-up-2" style={{ marginBottom: '2rem' }}>
        <div className="card stat-card"><div className="stat-icon" style={{ background: 'var(--accent-soft)' }}>📤</div><div><h3>{total}</h3><p>Total Raised</p></div></div>
        <div className="card stat-card"><div className="stat-icon" style={{ background: 'var(--green-soft)' }}>✅</div><div><h3>{solved}</h3><p>Resolved</p></div></div>
        <div className="card stat-card"><div className="stat-icon" style={{ background: 'var(--yellow-soft)' }}>⏳</div><div><h3>{pending}</h3><p>In Progress</p></div></div>
      </div>

      <div className="section-title fade-up fade-up-3">Quick Actions</div>
      <div className="grid grid-2 fade-up fade-up-3">
        <div className="card action-card card-clickable" onClick={() => onNavigate('form')}>
          <div className="action-card-icon" style={{ background: 'var(--accent-soft)' }}>📝</div>
          <h3>Any Complaints?</h3>
          <p>Submit a new complaint securely to your class incharge</p>
        </div>
        <div className="card action-card card-clickable" onClick={() => onNavigate('status')}>
          <div className="action-card-icon" style={{ background: 'var(--blue-soft)' }}>🔍</div>
          <h3>Check Complaint Status</h3>
          <p>Track if your complaint is accepted, being worked on, or solved</p>
        </div>
        <div className="card action-card card-clickable" onClick={() => onNavigate('profile')} style={{ gridColumn: '1/-1' }}>
          <div className="action-card-icon" style={{ background: 'var(--green-soft)' }}>✏️</div>
          <h3>Edit My Profile</h3>
          <p>Update your name, branch, section, course or password (Roll No is fixed)</p>
        </div>
      </div>
    </main>
  );
}

function ComplaintForm({ user, onBack, onSubmitDone, showToast }) {
  const [form, setForm] = useState({
    name: user.name || '', roll: user.rollNo || '',
    branch: user.branch || '', section: user.section || '',
    course: user.course || '', phone: '',
    title: '', desc: '', photo: null, photoName: ''
  });

  const set = (field, val) => setForm(f => ({ ...f, [field]: val }));

  const handlePhoto = (e) => {
    const file = e.target.files[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => set('photo', ev.target.result);
    reader.readAsDataURL(file);
    set('photoName', file.name);
  };

  const submit = () => {
    const { name, roll, branch, section, course, phone, title, desc } = form;
    if (!name || !roll || !branch || !section || !course || !phone || !title || !desc) {
      showToast('Please fill all required fields ✱', 'error'); return;
    }
    if (!/^\d{10}$/.test(phone)) { showToast('Phone number must be exactly 10 digits', 'error'); return; }

    const now = new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' });
    Complaints.add({
      id: genId(), studentUsername: user.username, studentName: name,
      rollNo: roll, branch, section, course, phone, title, description: desc,
      photo: form.photo || null, class: branch + '-' + section,
      status: 'pending', inchargeUsername: null, inchargeName: null,
      createdAt: now, history: [{ status: 'pending', note: 'Complaint submitted by student', time: now }]
    });
    showToast('✅ Complaint submitted securely!', 'success');
    setTimeout(() => onSubmitDone(), 700);
  };

  return (
    <main className="page-wrap">
      <BackBtn onClick={onBack} />
      <div className="page-header fade-up fade-up-1">
        <h1>Submit a Complaint 📝</h1>
        <p>Your complaint is sent securely and only visible to your class incharge.</p>
      </div>
      <div className="card fade-up fade-up-2" style={{ maxWidth: 680 }}>
        <div className="encrypted-tag">🔒 End-to-end encrypted — only your incharge can view this</div>
        <div className="form-row">
          <div className="form-group"><label>Full Name *</label><input type="text" value={form.name} onChange={e => set('name', e.target.value)} placeholder="Your full name" /></div>
          <div className="form-group"><label>Roll Number *</label><input type="text" value={form.roll} onChange={e => set('roll', e.target.value)} placeholder="e.g. 22CSM001" /></div>
        </div>
        <div className="form-row">
          <div className="form-group"><label>Branch *</label>
            <select value={form.branch} onChange={e => set('branch', e.target.value)}>
              <option value="">Select Branch</option>
              {['CSM','CSE','ECE','EEE','MECH','CIVIL','IT','AIDS'].map(b => <option key={b}>{b}</option>)}
            </select>
          </div>
          <div className="form-group"><label>Section *</label>
            <select value={form.section} onChange={e => set('section', e.target.value)}>
              <option value="">Select Section</option>
              {['A','B','C','D'].map(s => <option key={s}>{s}</option>)}
            </select>
          </div>
        </div>
        <div className="form-row">
          <div className="form-group"><label>Course *</label>
            <select value={form.course} onChange={e => set('course', e.target.value)}>
              <option value="">Select Course</option>
              {['B.Tech','M.Tech','MBA','MCA','BCA','B.Sc'].map(c => <option key={c}>{c}</option>)}
            </select>
          </div>
          <div className="form-group"><label>Phone Number *</label><input type="tel" value={form.phone} onChange={e => set('phone', e.target.value)} placeholder="10-digit number" maxLength={10} /></div>
        </div>
        <div className="form-group"><label>Complaint Title *</label><input type="text" value={form.title} onChange={e => set('title', e.target.value)} placeholder="Brief, clear subject of your complaint" /></div>
        <div className="form-group"><label>Description *</label><textarea value={form.desc} onChange={e => set('desc', e.target.value)} placeholder="Describe your complaint in detail. Be specific about what happened, where, and when." /></div>
        <div className="form-group">
          <label>Upload Photo / Evidence <span style={{ color: 'var(--text3)' }}>(optional)</span></label>
          <div className={`upload-zone${form.photo ? ' has-file' : ''}`} onClick={() => document.getElementById('f-photo').click()}>
            <input type="file" id="f-photo" accept="image/*" style={{ display: 'none' }} onChange={handlePhoto} />
            {form.photo
              ? <><img src={form.photo} className="photo-thumb" style={{ display: 'block', margin: '0 auto' }} alt="preview" /><div>✅ {form.photoName}</div></>
              : <div>📎 Click to upload or drag an image here</div>
            }
          </div>
        </div>
        <div className="form-actions">
          <button className="btn btn-ghost" onClick={onBack}>Cancel</button>
          <button className="btn btn-primary" onClick={submit}>🔒 Submit Securely</button>
        </div>
      </div>
    </main>
  );
}

function StatusView({ user, onBack }) {
  const complaints = Complaints.forStudent(user.username);
  return (
    <main className="page-wrap">
      <BackBtn onClick={onBack} />
      <div className="page-header fade-up fade-up-1">
        <h1>Complaint Status 🔍</h1>
        <p>All complaints you have raised — live status updates.</p>
      </div>
      <div className="fade-up fade-up-2">
        {!complaints.length
          ? <EmptyState icon="📭" message={"You haven't raised any complaints yet.<br/><b>Click \"Any Complaints?\"</b> on the dashboard to submit one."} />
          : complaints.slice().reverse().map(c => <ComplaintCard key={c.id} complaint={c} />)
        }
      </div>
    </main>
  );
}

function ProfileView({ user, onBack, showToast, refreshUser }) {
  const u = Accounts.findByUsername(user.username);
  const [name, setName] = useState(u.name || '');
  const [branch, setBranch] = useState(u.branch || '');
  const [section, setSection] = useState(u.section || '');
  const [course, setCourse] = useState(u.course || '');
  const [password, setPassword] = useState('');

  const save = () => {
    if (!name || !branch || !section || !course) { showToast('Name, branch, section and course are required', 'error'); return; }
    if (password && password.length < 4) { showToast('Password must be at least 4 characters', 'error'); return; }
    const updates = { name, branch, section, course };
    if (password) updates.password = password;
    Accounts.update(user.username, updates);
    refreshUser();
    showToast('✅ Profile updated successfully!', 'success');
    onBack();
  };

  return (
    <main className="page-wrap">
      <BackBtn onClick={onBack} />
      <div className="page-header fade-up fade-up-1"><h1>Edit My Profile ✏️</h1><p>Update your account info. Roll Number is fixed and cannot be changed.</p></div>
      <div className="card fade-up fade-up-2" style={{ maxWidth: 560 }}>
        <div className="form-group"><label>Full Name *</label><input type="text" value={name} onChange={e => setName(e.target.value)} /></div>
        <div className="form-row">
          <div className="form-group"><label>Branch *</label>
            <select value={branch} onChange={e => setBranch(e.target.value)}>
              <option value="">Select Branch</option>
              {['CSM','CSE','ECE','EEE','MECH','CIVIL','IT','AIDS'].map(b => <option key={b}>{b}</option>)}
            </select>
          </div>
          <div className="form-group"><label>Section *</label>
            <select value={section} onChange={e => setSection(e.target.value)}>
              <option value="">Select Section</option>
              {['A','B','C','D'].map(s => <option key={s}>{s}</option>)}
            </select>
          </div>
        </div>
        <div className="form-group"><label>Course *</label>
          <select value={course} onChange={e => setCourse(e.target.value)}>
            <option value="">Select Course</option>
            {['B.Tech','M.Tech','MBA','MCA','BCA','B.Sc'].map(c => <option key={c}>{c}</option>)}
          </select>
        </div>
        <div className="form-group"><label>Roll Number <span style={{ color: 'var(--text3)', fontSize: '0.78rem' }}>🔒 Cannot be changed</span></label><input type="text" value={u.rollNo || ''} disabled style={{ opacity: 0.55, cursor: 'not-allowed' }} /></div>
        <div className="form-group"><label>New Password <span style={{ color: 'var(--text3)', fontSize: '0.78rem' }}>(leave blank to keep current)</span></label><input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Enter new password" /></div>
        <div className="form-actions">
          <button className="btn btn-ghost" onClick={onBack}>Cancel</button>
          <button className="btn btn-primary" onClick={save}>💾 Save Changes</button>
        </div>
      </div>
    </main>
  );
}

export default function StudentPage() {
  const { currentUser, showToast, refreshUser } = useApp();
  const [view, setView] = useState('dashboard');

  const nav = useCallback((v) => { setView(v); window.scrollTo({ top: 0, behavior: 'smooth' }); }, []);

  return (
    <>
      <Header onLogoClick={() => nav('dashboard')} />
      {view === 'dashboard' && <Dashboard user={currentUser} onNavigate={nav} />}
      {view === 'form'      && <ComplaintForm user={currentUser} onBack={() => nav('dashboard')} onSubmitDone={() => nav('status')} showToast={showToast} />}
      {view === 'status'    && <StatusView user={currentUser} onBack={() => nav('dashboard')} />}
      {view === 'profile'   && <ProfileView user={currentUser} onBack={() => nav('dashboard')} showToast={showToast} refreshUser={refreshUser} />}
      <Footer />
      <Toast />
    </>
  );
}
